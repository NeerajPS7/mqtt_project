import paho.mqtt.client as mqtt
import json
import time
from datetime import datetime
broker_address = "broker.mqttdashboard.com"
client = mqtt.Client()
client.connect(broker_address,1883)
publisher_topic = "devicee/EO1/"
Expected_time=3600
start_time = time.time()
while time.time() - start_time < Expected_time:
    now = datetime.now()
    date_time=now.strftime("%Y:%m:%d:%H:%M:%S.%f")
    payload = {
    "did": "EO1",
    "temperature": 37,
    "timestamp": date_time
    }
    print(date_time)
    client.publish(publisher_topic, json.dumps(payload))
    time.sleep(10)
client.disconnect()