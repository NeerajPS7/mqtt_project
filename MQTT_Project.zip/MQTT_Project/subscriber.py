import paho.mqtt.client as mqtt
import json
import time
import csv
from datetime import datetime
format="%Y:%m:%d:%H:%M:%S.%f"

def on_message(client, userdata, message):
    payload = json.loads(message.payload.decode("utf-8"))
    date=datetime.strptime(payload["timestamp"],format)
    #print(time.time())
    #print(date.timestamp())
    latency = time.time() - date.timestamp()
    #print(latency)
    print(payload)
    
    #Maximum latency
    if latency > results["max_latency"]:
        results["max_latency"] = latency
    #Minimum latency
    if latency < results["min_latency"]:
        results["min_latency"] = latency
    results["total_latency"] += latency
    results["packet_count"] += 1
    

broker_address = "broker.mqttdashboard.com"
client = mqtt.Client()
client.connect(broker_address,1883)
Expected_time=3600

subscriber_topic = "devicee/#"
client.subscribe(subscriber_topic)
start_time = time.time()
results = {
    "packet_num":0,   
    "max_latency": 0,
    "min_latency": float("inf"),
    "total_latency": 0,
    "packet_count": 0,
    "packet_drop": 0
}
while time.time() - start_time < Expected_time:  
    client.on_message = on_message
    client.loop(timeout=1)

client.disconnect()

#print(len(results["Latencies"]))
results["avg_latency"] = results["total_latency"] / results["packet_count"] #average latency
#Packet drop count
print("No of packets received:",results["packet_count"])
results["packet_drop"]=(Expected_time/10)-results["packet_count"]
with open("results.csv", "w", newline="") as csvfile:
    fieldnames = ["Total Latency", "Maximum", "Minimum", "Average", "Packet Drop"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerow({
        "Total Latency": round(results["total_latency"], 2),
        "Maximum": round(results["max_latency"], 2),
        "Minimum": round(results["min_latency"], 2),
        "Average": round(results["avg_latency"], 2),
        "Packet Drop": results["packet_drop"]
    })

with open('results.csv', mode='r') as results_file:
    results_reader = csv.reader(results_file)
    for row in results_reader:
        print(','.join(row))